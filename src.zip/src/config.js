export const birthdayConfig = {
  name: "NAME",
  message: "I hope today reminds you how deeply loved you are. Keep choosing joy, chasing the things that light you up, and making ordinary moments feel magical. The world is brighter with you in it.",
  finalMessage: "May your day be filled with happiness,\nyour year with beautiful memories,\nand your future with everything you've dreamed of.",
};
